import { useState } from "react";
import {
  Search, Monitor, Star, Battery, Wifi, Signal,
  MapPin, Trophy, LayoutList, Calendar, User, Sliders, Navigation,
} from "lucide-react";

const CLUBS = [
  { id: 1, name: "CYBERIA PRO", x: 42, y: 36, rating: 4.9, pcs: 24, avail: 8, color: "#00D4FF", tier: "VIP" },
  { id: 2, name: "VORTEX ARENA", x: 64, y: 54, rating: 4.7, pcs: 60, avail: 12, color: "#A855F7", tier: "PRO" },
  { id: 3, name: "PIXEL HUB", x: 27, y: 63, rating: 4.5, pcs: 30, avail: 3, color: "#FF6B00", tier: "STD" },
  { id: 4, name: "NEON ZONE", x: 74, y: 27, rating: 4.8, pcs: 45, avail: 20, color: "#00D4FF", tier: "VIP" },
  { id: 5, name: "MATRIX CLUB", x: 50, y: 74, rating: 4.6, pcs: 36, avail: 5, color: "#A855F7", tier: "PRO" },
];

const BUILDINGS = [
  { x: 5, y: 6, w: 12, h: 9 }, { x: 22, y: 4, w: 7, h: 14 },
  { x: 35, y: 8, w: 16, h: 9 }, { x: 55, y: 3, w: 11, h: 16 },
  { x: 72, y: 7, w: 9, h: 12 }, { x: 85, y: 4, w: 10, h: 9 },
  { x: 7, y: 28, w: 10, h: 14 }, { x: 22, y: 26, w: 13, h: 11 },
  { x: 44, y: 20, w: 12, h: 20 }, { x: 79, y: 20, w: 8, h: 14 },
  { x: 88, y: 26, w: 8, h: 18 }, { x: 5, y: 50, w: 13, h: 18 },
  { x: 26, y: 48, w: 9, h: 13 }, { x: 42, y: 46, w: 15, h: 10 },
  { x: 61, y: 42, w: 11, h: 18 }, { x: 77, y: 48, w: 10, h: 14 },
  { x: 88, y: 46, w: 8, h: 16 }, { x: 8, y: 76, w: 12, h: 13 },
  { x: 26, y: 73, w: 14, h: 13 }, { x: 46, y: 78, w: 11, h: 13 },
  { x: 63, y: 74, w: 13, h: 14 }, { x: 80, y: 76, w: 11, h: 14 },
];

const NAV = [
  { icon: MapPin, label: "Карта" },
  { icon: Trophy, label: "Турниры" },
  { icon: LayoutList, label: "Лента" },
  { icon: Calendar, label: "Бронь" },
  { icon: User, label: "Профиль" },
];

export function MapScreen() {
  const [selected, setSelected] = useState(CLUBS[0]);
  const [activeNav, setActiveNav] = useState("Карта");

  return (
    <div style={{ height: "100%", display: "flex", flexDirection: "column", background: "#060912", fontFamily: "Inter, sans-serif", overflow: "hidden" }}>
      {/* Status */}
      <div style={{ paddingTop: 50, paddingLeft: 20, paddingRight: 20, paddingBottom: 6, display: "flex", justifyContent: "space-between", alignItems: "center", flexShrink: 0 }}>
        <span style={{ color: "#fff", fontSize: 12, fontFamily: "DM Mono, monospace", fontWeight: 500 }}>9:41</span>
        <div style={{ display: "flex", gap: 5, alignItems: "center" }}>
          <Signal size={11} color="rgba(255,255,255,0.9)" />
          <Wifi size={11} color="rgba(255,255,255,0.9)" />
          <Battery size={11} color="rgba(255,255,255,0.9)" />
        </div>
      </div>

      {/* Search */}
      <div style={{ padding: "4px 14px 8px", flexShrink: 0 }}>
        <div style={{
          background: "rgba(255,255,255,0.05)",
          backdropFilter: "blur(20px)",
          WebkitBackdropFilter: "blur(20px)",
          border: "1px solid rgba(0,212,255,0.2)",
          borderRadius: 14,
          padding: "9px 14px",
          display: "flex",
          alignItems: "center",
          gap: 10,
          boxShadow: "0 0 20px rgba(0,212,255,0.06)",
        }}>
          <Search size={14} color="#00D4FF" />
          <span style={{ color: "rgba(255,255,255,0.35)", fontSize: 13, flex: 1 }}>Найти клуб или арену...</span>
          <Sliders size={13} color="rgba(255,255,255,0.3)" />
        </div>
      </div>

      {/* Map */}
      <div style={{ flex: 1, position: "relative", overflow: "hidden" }}>
        {/* Map BG */}
        <div style={{
          position: "absolute",
          inset: 0,
          background: "#060912",
          backgroundImage: `
            linear-gradient(rgba(0,212,255,0.035) 1px, transparent 1px),
            linear-gradient(90deg, rgba(0,212,255,0.035) 1px, transparent 1px),
            radial-gradient(ellipse at 50% 50%, rgba(0,212,255,0.04) 0%, transparent 65%)
          `,
          backgroundSize: "30px 30px, 30px 30px, 100% 100%",
        }}>
          {/* Buildings */}
          {BUILDINGS.map((b, i) => (
            <div key={i} style={{
              position: "absolute",
              left: `${b.x}%`,
              top: `${b.y}%`,
              width: `${b.w}%`,
              height: `${b.h}%`,
              background: i % 3 === 0 ? "rgba(0,212,255,0.04)" : i % 3 === 1 ? "rgba(168,85,247,0.04)" : "rgba(255,107,0,0.03)",
              border: `1px solid ${i % 3 === 0 ? "rgba(0,212,255,0.07)" : i % 3 === 1 ? "rgba(168,85,247,0.07)" : "rgba(255,107,0,0.06)"}`,
              borderRadius: 2,
            }} />
          ))}

          {/* Streets */}
          <div style={{ position: "absolute", top: "42%", left: 0, right: 0, height: 2, background: "rgba(0,212,255,0.07)" }} />
          <div style={{ position: "absolute", top: "71%", left: 0, right: 0, height: 1, background: "rgba(0,212,255,0.05)" }} />
          <div style={{ position: "absolute", left: "40%", top: 0, bottom: 0, width: 2, background: "rgba(0,212,255,0.07)" }} />
          <div style={{ position: "absolute", left: "72%", top: 0, bottom: 0, width: 1, background: "rgba(0,212,255,0.05)" }} />

          {/* User loc */}
          <div style={{ position: "absolute", top: "50%", left: "50%", transform: "translate(-50%,-50%)", zIndex: 10 }}>
            <div style={{
              width: 14, height: 14, borderRadius: "50%",
              background: "#00D4FF", border: "2.5px solid #fff",
              boxShadow: "0 0 0 8px rgba(0,212,255,0.15), 0 0 24px rgba(0,212,255,0.5)",
            }} />
          </div>

          {/* Pins */}
          {CLUBS.map((club) => (
            <button
              key={club.id}
              onClick={() => setSelected(club)}
              style={{
                position: "absolute",
                left: `${club.x}%`,
                top: `${club.y}%`,
                transform: "translate(-50%, -100%)",
                background: "none",
                border: "none",
                cursor: "pointer",
                zIndex: 20,
                padding: 0,
              }}
            >
              {selected.id === club.id && (
                <>
                  <div style={{
                    position: "absolute", top: 0, left: "50%",
                    transform: "translateX(-50%)",
                    width: 40, height: 40, borderRadius: "50%",
                    background: `${club.color}20`,
                    animation: "gmap-pulse 1.8s ease-out infinite",
                  }} />
                  <div style={{
                    position: "absolute", top: 0, left: "50%",
                    transform: "translateX(-50%)",
                    width: 40, height: 40, borderRadius: "50%",
                    background: `${club.color}10`,
                    animation: "gmap-pulse 1.8s ease-out infinite 0.5s",
                  }} />
                </>
              )}
              <div style={{
                width: 32,
                height: 32,
                borderRadius: "50% 50% 50% 0",
                transform: "rotate(-45deg)",
                background: `linear-gradient(135deg, ${club.color}, ${club.color}80)`,
                boxShadow: `0 0 10px ${club.color}90, 0 0 20px ${club.color}50`,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                border: selected.id === club.id ? `2px solid #fff` : `1px solid ${club.color}50`,
                transition: "all 0.2s",
              }}>
                <Monitor size={11} color="#fff" style={{ transform: "rotate(45deg)" }} />
              </div>
            </button>
          ))}

          {/* Nav hint */}
          <div style={{ position: "absolute", top: 10, right: 12, zIndex: 30 }}>
            <div style={{
              width: 36, height: 36, borderRadius: 10,
              background: "rgba(0,212,255,0.12)",
              backdropFilter: "blur(10px)",
              border: "1px solid rgba(0,212,255,0.25)",
              display: "flex", alignItems: "center", justifyContent: "center",
              boxShadow: "0 0 12px rgba(0,212,255,0.2)",
            }}>
              <Navigation size={16} color="#00D4FF" />
            </div>
          </div>
        </div>

        {/* Bottom sheet */}
        <div style={{
          position: "absolute", bottom: 0, left: 0, right: 0,
          background: "rgba(6,9,18,0.88)",
          backdropFilter: "blur(30px)",
          WebkitBackdropFilter: "blur(30px)",
          borderTop: "1px solid rgba(0,212,255,0.2)",
          borderRadius: "22px 22px 0 0",
          padding: "10px 14px 14px",
          boxShadow: "0 -4px 40px rgba(0,0,0,0.6), 0 0 30px rgba(0,212,255,0.05)",
        }}>
          <div style={{ width: 32, height: 3, background: "rgba(255,255,255,0.12)", borderRadius: 2, margin: "0 auto 10px" }} />
          <div style={{ display: "flex", gap: 10, marginBottom: 10 }}>
            <div style={{ width: 60, height: 60, borderRadius: 12, overflow: "hidden", flexShrink: 0, border: "1px solid rgba(0,212,255,0.2)" }}>
              <img
                src="https://images.unsplash.com/photo-1603481588273-2f908a9a7a1b?w=120&h=120&fit=crop&auto=format"
                alt="Клуб"
                style={{ width: "100%", height: "100%", objectFit: "cover" }}
              />
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 2 }}>
                <span style={{ color: "#fff", fontSize: 13, fontWeight: 700, fontFamily: "Rajdhani, sans-serif", letterSpacing: "0.06em" }}>
                  {selected.name}
                </span>
                <div style={{
                  background: `${selected.color}20`,
                  border: `1px solid ${selected.color}40`,
                  borderRadius: 4, padding: "0px 5px",
                  fontSize: 8, color: selected.color,
                  fontFamily: "Orbitron, sans-serif", fontWeight: 700,
                }}>{selected.tier}</div>
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: 3, marginBottom: 5 }}>
                <Star size={10} color="#FFB800" fill="#FFB800" />
                <span style={{ color: "#FFB800", fontSize: 11, fontWeight: 600 }}>{selected.rating}</span>
                <span style={{ color: "rgba(255,255,255,0.25)", fontSize: 10 }}>· 128 отзывов</span>
              </div>
              <div style={{ display: "flex", gap: 10 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 3 }}>
                  <Monitor size={10} color="rgba(255,255,255,0.4)" />
                  <span style={{ color: "rgba(255,255,255,0.55)", fontSize: 10 }}>{selected.pcs} ПК</span>
                </div>
                <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
                  <div style={{
                    width: 6, height: 6, borderRadius: "50%",
                    background: selected.avail > 5 ? "#00FF88" : "#FF6B00",
                    boxShadow: `0 0 7px ${selected.avail > 5 ? "#00FF88" : "#FF6B00"}`,
                  }} />
                  <span style={{ color: selected.avail > 5 ? "#00FF88" : "#FF6B00", fontSize: 10, fontWeight: 600 }}>
                    {selected.avail} свободно
                  </span>
                </div>
              </div>
            </div>
          </div>

          <div style={{ display: "flex", gap: 6, marginBottom: 10 }}>
            {[["RTX 4090", "#00D4FF"], ["240 Гц", "#A855F7"], ["DDR5 32GB", "#FF6B00"]].map(([spec, col]) => (
              <div key={spec} style={{
                flex: 1, background: "rgba(255,255,255,0.03)",
                border: `1px solid ${col}30`, borderRadius: 8,
                padding: "5px 4px", textAlign: "center",
              }}>
                <span style={{ color: col, fontSize: 10, fontWeight: 700, fontFamily: "DM Mono, monospace" }}>{spec}</span>
              </div>
            ))}
          </div>

          <button style={{
            width: "100%", padding: "11px 0",
            borderRadius: 13,
            background: "linear-gradient(90deg, #00D4FF 0%, #A855F7 100%)",
            border: "none", color: "#fff",
            fontSize: 13, fontWeight: 800,
            fontFamily: "Rajdhani, sans-serif", letterSpacing: "0.12em",
            cursor: "pointer",
            boxShadow: "0 0 20px rgba(0,212,255,0.35), 0 0 40px rgba(168,85,247,0.2)",
          }}>
            ЗАБРОНИРОВАТЬ
          </button>
        </div>
      </div>

      {/* Bottom nav */}
      <div style={{
        flexShrink: 0,
        background: "rgba(6,9,18,0.97)",
        backdropFilter: "blur(20px)",
        borderTop: "1px solid rgba(255,255,255,0.05)",
        display: "flex",
        padding: "7px 0 18px",
      }}>
        {NAV.map(({ icon: Icon, label }) => {
          const active = activeNav === label;
          return (
            <button
              key={label}
              onClick={() => setActiveNav(label)}
              style={{
                flex: 1, display: "flex", flexDirection: "column",
                alignItems: "center", gap: 3,
                background: "none", border: "none", cursor: "pointer", padding: "3px 0",
              }}
            >
              <Icon
                size={19}
                color={active ? "#00D4FF" : "rgba(255,255,255,0.3)"}
                style={active ? { filter: "drop-shadow(0 0 5px rgba(0,212,255,0.9))" } : {}}
              />
              <span style={{
                fontSize: 8.5,
                color: active ? "#00D4FF" : "rgba(255,255,255,0.3)",
                fontFamily: "Inter, sans-serif",
                fontWeight: active ? 600 : 400,
              }}>{label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
