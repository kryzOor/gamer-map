import { useState } from "react";
import {
  ArrowLeft, Share2, Heart, Star, Monitor, Users,
  Zap, Wifi, Trophy, Camera, ChevronRight, BadgeCheck,
  Battery, Signal,
} from "lucide-react";

const STORIES = [
  { label: "Турниры", color: "#00D4FF", icon: Trophy },
  { label: "Акции", color: "#A855F7", icon: Zap },
  { label: "Фото", color: "#FF6B00", icon: Camera },
  { label: "Итоги", color: "#00FF88", icon: Star },
];

const PHOTOS = [
  "photo-1603481588273-2f908a9a7a1b",
  "photo-1616588589676-62b3bd4ff6d2",
  "photo-1614179924047-e1ab49a0a0cf",
  "photo-1544652478-6653e09f18a2",
  "photo-1696710257827-75e2e5954059",
  "photo-1610041321420-a596dd14ebc9",
];

const STATS = [
  { label: "Подписчиков", value: "12.4K", color: "#00D4FF" },
  { label: "Турниров", value: "38", color: "#A855F7" },
  { label: "Рейтинг", value: "4.9", color: "#FFB800" },
];

export function ClubScreen() {
  const [liked, setLiked] = useState(false);
  const [followed, setFollowed] = useState(false);

  return (
    <div style={{ height: "100%", display: "flex", flexDirection: "column", background: "#060912", fontFamily: "Inter, sans-serif", overflow: "hidden" }}>
      {/* Scrollable content */}
      <div style={{ flex: 1, overflowY: "auto", scrollbarWidth: "none" }}>
        {/* Header image */}
        <div style={{ position: "relative", height: 260, flexShrink: 0 }}>
          <img
            src="https://images.unsplash.com/photo-1616588589676-62b3bd4ff6d2?w=680&h=520&fit=crop&auto=format"
            alt="VIP gaming room"
            style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }}
          />
          {/* Overlay gradient */}
          <div style={{
            position: "absolute", inset: 0,
            background: "linear-gradient(to bottom, rgba(6,9,18,0.6) 0%, transparent 35%, rgba(6,9,18,0.7) 75%, #060912 100%)",
          }} />

          {/* Status bar */}
          <div style={{
            position: "absolute", top: 0, left: 0, right: 0,
            paddingTop: 50, paddingLeft: 18, paddingRight: 18, paddingBottom: 6,
            display: "flex", justifyContent: "space-between", alignItems: "center",
          }}>
            <span style={{ color: "#fff", fontSize: 12, fontFamily: "DM Mono, monospace" }}>9:41</span>
            <div style={{ display: "flex", gap: 5 }}>
              <Signal size={11} color="#fff" />
              <Wifi size={11} color="#fff" />
              <Battery size={11} color="#fff" />
            </div>
          </div>

          {/* Top nav */}
          <div style={{
            position: "absolute", top: 56, left: 0, right: 0,
            display: "flex", alignItems: "center", justifyContent: "space-between",
            padding: "0 14px",
          }}>
            <div style={{
              width: 34, height: 34, borderRadius: 10,
              background: "rgba(6,9,18,0.6)",
              backdropFilter: "blur(12px)",
              border: "1px solid rgba(255,255,255,0.12)",
              display: "flex", alignItems: "center", justifyContent: "center",
            }}>
              <ArrowLeft size={16} color="#fff" />
            </div>
            <div style={{
              background: "rgba(6,9,18,0.6)",
              backdropFilter: "blur(12px)",
              border: "1px solid rgba(0,212,255,0.2)",
              borderRadius: 10, padding: "5px 12px",
            }}>
              <span style={{ color: "#00D4FF", fontSize: 11, fontWeight: 700, fontFamily: "Orbitron, sans-serif" }}>
                GAMERMAP
              </span>
            </div>
            <button
              onClick={() => setLiked(!liked)}
              style={{
                width: 34, height: 34, borderRadius: 10,
                background: "rgba(6,9,18,0.6)",
                backdropFilter: "blur(12px)",
                border: `1px solid ${liked ? "rgba(255,45,85,0.4)" : "rgba(255,255,255,0.12)"}`,
                display: "flex", alignItems: "center", justifyContent: "center",
                cursor: "pointer",
              }}
            >
              <Heart size={15} color={liked ? "#FF2D55" : "#fff"} fill={liked ? "#FF2D55" : "none"} />
            </button>
          </div>

          {/* VIP badge */}
          <div style={{
            position: "absolute", bottom: 70, left: 14,
            background: "linear-gradient(135deg, #00D4FF, #A855F7)",
            borderRadius: 8, padding: "3px 10px",
            boxShadow: "0 0 16px rgba(0,212,255,0.5)",
          }}>
            <span style={{ color: "#fff", fontSize: 9, fontWeight: 800, fontFamily: "Orbitron, sans-serif", letterSpacing: "0.1em" }}>
              VIP ЗОНА
            </span>
          </div>

          {/* Club name */}
          <div style={{ position: "absolute", bottom: 14, left: 14, right: 14 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 2 }}>
              <span style={{ color: "#fff", fontSize: 20, fontWeight: 800, fontFamily: "Rajdhani, sans-serif", letterSpacing: "0.05em" }}>
                CYBERIA PRO
              </span>
              <BadgeCheck size={16} color="#00D4FF" fill="rgba(0,212,255,0.2)" />
            </div>
            <span style={{ color: "rgba(255,255,255,0.55)", fontSize: 11 }}>Москва · Тверская, 14 · Открыт 24/7</span>
          </div>
        </div>

        {/* Glassmorphic stat cards */}
        <div style={{ display: "flex", gap: 8, padding: "10px 14px 0", marginTop: -8 }}>
          {STATS.map(({ label, value, color }) => (
            <div key={label} style={{
              flex: 1,
              background: "rgba(255,255,255,0.04)",
              backdropFilter: "blur(20px)",
              WebkitBackdropFilter: "blur(20px)",
              border: `1px solid ${color}25`,
              borderRadius: 12,
              padding: "8px 6px",
              textAlign: "center",
              boxShadow: `0 0 12px ${color}10`,
            }}>
              <div style={{ color, fontSize: 15, fontWeight: 800, fontFamily: "Orbitron, sans-serif", marginBottom: 1 }}>{value}</div>
              <div style={{ color: "rgba(255,255,255,0.4)", fontSize: 9, fontFamily: "Inter, sans-serif" }}>{label}</div>
            </div>
          ))}
        </div>

        {/* Specs row glassmorphic */}
        <div style={{ margin: "10px 14px 0" }}>
          <div style={{
            background: "rgba(255,255,255,0.03)",
            backdropFilter: "blur(20px)",
            border: "1px solid rgba(168,85,247,0.2)",
            borderRadius: 14,
            padding: "10px 14px",
            boxShadow: "0 0 20px rgba(168,85,247,0.06)",
          }}>
            <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 8 }}>
              <Monitor size={13} color="#A855F7" />
              <span style={{ color: "#A855F7", fontSize: 10, fontWeight: 700, fontFamily: "Orbitron, sans-serif", letterSpacing: "0.08em" }}>
                КОНФИГУРАЦИЯ СТАНЦИЙ
              </span>
            </div>
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
              {[["RTX 4090 Ti", "#00D4FF"], ["i9-14900KS", "#00D4FF"], ["240 Гц 1ms", "#A855F7"], ["DDR5 64GB", "#A855F7"], ["NVMe 2TB", "#FF6B00"], ["7.1 Звук", "#FF6B00"]].map(([spec, col]) => (
                <div key={spec} style={{
                  background: `${col}12`,
                  border: `1px solid ${col}30`,
                  borderRadius: 6, padding: "3px 8px",
                }}>
                  <span style={{ color: col, fontSize: 9, fontWeight: 700, fontFamily: "DM Mono, monospace" }}>{spec}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Ping stat */}
        <div style={{ margin: "8px 14px 0" }}>
          <div style={{
            background: "rgba(255,255,255,0.03)",
            backdropFilter: "blur(20px)",
            border: "1px solid rgba(0,212,255,0.15)",
            borderRadius: 14, padding: "10px 14px",
            display: "flex", alignItems: "center", justifyContent: "space-between",
          }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <Wifi size={14} color="#00D4FF" />
              <div>
                <div style={{ color: "rgba(255,255,255,0.5)", fontSize: 9, marginBottom: 1 }}>СРЕДНИЙ ПИНГ</div>
                <div style={{ color: "#00FF88", fontSize: 14, fontWeight: 800, fontFamily: "DM Mono, monospace" }}>
                  3 мс
                  <span style={{ color: "rgba(255,255,255,0.4)", fontSize: 9, fontWeight: 400, marginLeft: 4 }}>· 10 Гбит/с</span>
                </div>
              </div>
            </div>
            <div style={{ display: "flex", gap: 3, alignItems: "flex-end" }}>
              {[4, 7, 5, 9, 8, 10, 7, 9, 10, 8].map((h, i) => (
                <div key={i} style={{
                  width: 4, height: `${h * 2.5}px`,
                  background: i > 6 ? "#00FF88" : "rgba(0,255,136,0.3)",
                  borderRadius: 2,
                }} />
              ))}
            </div>
          </div>
        </div>

        {/* Follow / Share */}
        <div style={{ display: "flex", gap: 8, margin: "10px 14px 0" }}>
          <button
            onClick={() => setFollowed(!followed)}
            style={{
              flex: 1, padding: "10px 0",
              borderRadius: 12,
              background: followed ? "rgba(0,212,255,0.12)" : "linear-gradient(90deg,#00D4FF,#A855F7)",
              border: followed ? "1px solid rgba(0,212,255,0.35)" : "none",
              color: "#fff",
              fontSize: 12, fontWeight: 700,
              fontFamily: "Rajdhani, sans-serif", letterSpacing: "0.08em",
              cursor: "pointer",
              boxShadow: followed ? "none" : "0 0 20px rgba(0,212,255,0.3)",
            }}
          >
            {followed ? "ПОДПИСАН" : "ПОДПИСАТЬСЯ"}
          </button>
          <button style={{
            width: 42, height: 42, borderRadius: 12,
            background: "rgba(255,255,255,0.05)",
            border: "1px solid rgba(255,255,255,0.1)",
            display: "flex", alignItems: "center", justifyContent: "center",
            cursor: "pointer",
          }}>
            <Share2 size={16} color="rgba(255,255,255,0.7)" />
          </button>
        </div>

        {/* Highlights */}
        <div style={{ padding: "12px 14px 0" }}>
          <div style={{ color: "rgba(255,255,255,0.4)", fontSize: 10, fontWeight: 600, letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 8 }}>Актуальное</div>
          <div style={{ display: "flex", gap: 10 }}>
            {STORIES.map(({ label, color, icon: Icon }) => (
              <div key={label} style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 5 }}>
                <div style={{
                  width: 52, height: 52, borderRadius: "50%",
                  background: `${color}18`,
                  border: `2px solid ${color}`,
                  display: "flex", alignItems: "center", justifyContent: "center",
                  boxShadow: `0 0 12px ${color}40`,
                }}>
                  <Icon size={20} color={color} />
                </div>
                <span style={{ color: "rgba(255,255,255,0.6)", fontSize: 9, fontFamily: "Inter, sans-serif" }}>{label}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Photo grid */}
        <div style={{ padding: "12px 14px 0" }}>
          <div style={{ color: "rgba(255,255,255,0.4)", fontSize: 10, fontWeight: 600, letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 8 }}>Фотографии</div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 2 }}>
            {PHOTOS.map((id) => (
              <div key={id} style={{ aspectRatio: "1", overflow: "hidden", borderRadius: 4 }}>
                <img
                  src={`https://images.unsplash.com/${id}?w=200&h=200&fit=crop&auto=format`}
                  alt="Клуб"
                  style={{ width: "100%", height: "100%", objectFit: "cover" }}
                />
              </div>
            ))}
          </div>
        </div>

        {/* Book CTA */}
        <div style={{ margin: "12px 14px 20px" }}>
          <button style={{
            width: "100%", padding: "12px 0",
            borderRadius: 14,
            background: "linear-gradient(90deg,#00D4FF,#A855F7)",
            border: "none", color: "#fff",
            fontSize: 13, fontWeight: 800,
            fontFamily: "Rajdhani, sans-serif", letterSpacing: "0.12em",
            cursor: "pointer",
            boxShadow: "0 0 24px rgba(0,212,255,0.35), 0 0 48px rgba(168,85,247,0.2)",
            display: "flex", alignItems: "center", justifyContent: "center", gap: 8,
          }}>
            ЗАБРОНИРОВАТЬ МЕСТО
            <ChevronRight size={16} />
          </button>
        </div>
      </div>
    </div>
  );
}
