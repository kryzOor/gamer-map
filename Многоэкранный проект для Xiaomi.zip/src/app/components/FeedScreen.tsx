import { useState } from "react";
import {
  Heart, MessageCircle, Share2, BadgeCheck, MapPin,
  Trophy, Flame, ChevronRight, Bell, Search,
  MapPin as Location, Users, Zap, Battery, Wifi, Signal,
  LayoutList, Calendar, User,
} from "lucide-react";

const STORIES = [
  { name: "Моя", url: "photo-1610041321420-a596dd14ebc9", color: "#00D4FF", isMe: true },
  { name: "VORTEX", url: "photo-1696710257827-75e2e5954059", color: "#A855F7" },
  { name: "n1ko", url: "photo-1544652478-6653e09f18a2", color: "#FF6B00" },
  { name: "PRO_MSK", url: "photo-1634910440823-193b061d28a5", color: "#00FF88" },
  { name: "s1mple", url: "photo-1580046939256-c377c5b099f1", color: "#00D4FF" },
];

function BracketLine({ team1, team2, winner, score1, score2 }: { team1: string; team2: string; winner: 1 | 2; score1: string; score2: string }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 2 }}>
      {[{ t: team1, s: score1, w: winner === 1 }, { t: team2, s: score2, w: winner === 2 }].map(({ t, s, w }, i) => (
        <div key={i} style={{
          display: "flex", alignItems: "center", justifyContent: "space-between",
          background: w ? "rgba(0,212,255,0.1)" : "rgba(255,255,255,0.04)",
          border: `1px solid ${w ? "rgba(0,212,255,0.3)" : "rgba(255,255,255,0.06)"}`,
          borderRadius: 5, padding: "3px 7px",
        }}>
          <span style={{ color: w ? "#fff" : "rgba(255,255,255,0.5)", fontSize: 9.5, fontWeight: w ? 700 : 400, fontFamily: "Inter, sans-serif" }}>{t}</span>
          <span style={{ color: w ? "#00D4FF" : "rgba(255,255,255,0.35)", fontSize: 9.5, fontWeight: 700, fontFamily: "DM Mono, monospace" }}>{s}</span>
        </div>
      ))}
    </div>
  );
}

function PostCard() {
  const [liked, setLiked] = useState(false);
  const [likes, setLikes] = useState(847);
  const [joined, setJoined] = useState(false);

  const toggleLike = () => {
    setLiked(!liked);
    setLikes(l => liked ? l - 1 : l + 1);
  };

  return (
    <div style={{
      margin: "0 12px 12px",
      background: "rgba(255,255,255,0.035)",
      backdropFilter: "blur(24px)",
      WebkitBackdropFilter: "blur(24px)",
      border: "1px solid rgba(255,255,255,0.07)",
      borderRadius: 18,
      overflow: "hidden",
      boxShadow: "0 4px 40px rgba(0,0,0,0.4), 0 0 0 1px rgba(168,85,247,0.05)",
    }}>
      {/* Post header */}
      <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "12px 14px 10px" }}>
        <div style={{ position: "relative" }}>
          <div style={{
            width: 40, height: 40, borderRadius: "50%",
            border: "2px solid #A855F7",
            overflow: "hidden",
            boxShadow: "0 0 12px rgba(168,85,247,0.6)",
          }}>
            <img
              src="https://images.unsplash.com/photo-1696710257827-75e2e5954059?w=80&h=80&fit=crop&auto=format"
              alt="Club"
              style={{ width: "100%", height: "100%", objectFit: "cover" }}
            />
          </div>
          <div style={{
            position: "absolute", bottom: -1, right: -1,
            width: 14, height: 14, borderRadius: "50%",
            background: "#00FF88",
            border: "2px solid #060912",
            boxShadow: "0 0 6px #00FF88",
          }} />
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
            <span style={{ color: "#fff", fontSize: 12, fontWeight: 700, fontFamily: "Rajdhani, sans-serif", letterSpacing: "0.04em" }}>
              VORTEX ARENA
            </span>
            <BadgeCheck size={13} color="#A855F7" />
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 3 }}>
            <Location size={9} color="rgba(255,255,255,0.35)" />
            <span style={{ color: "rgba(255,255,255,0.35)", fontSize: 9 }}>Москва · 2 часа назад</span>
          </div>
        </div>
        <div style={{
          background: "rgba(255,107,0,0.15)",
          border: "1px solid rgba(255,107,0,0.35)",
          borderRadius: 6, padding: "2px 7px",
          boxShadow: "0 0 8px rgba(255,107,0,0.2)",
        }}>
          <span style={{ color: "#FF6B00", fontSize: 8.5, fontWeight: 700, fontFamily: "Orbitron, sans-serif" }}>LIVE</span>
        </div>
      </div>

      {/* Post image */}
      <div style={{ position: "relative", height: 140 }}>
        <img
          src="https://images.unsplash.com/photo-1544652478-6653e09f18a2?w=680&h=280&fit=crop&auto=format"
          alt="Турнир"
          style={{ width: "100%", height: "100%", objectFit: "cover" }}
        />
        <div style={{ position: "absolute", inset: 0, background: "linear-gradient(to bottom, rgba(6,9,18,0.3) 0%, rgba(6,9,18,0.7) 100%)" }} />
        <div style={{ position: "absolute", bottom: 10, left: 14, right: 14, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div>
            <div style={{ color: "#fff", fontSize: 14, fontWeight: 800, fontFamily: "Rajdhani, sans-serif", letterSpacing: "0.06em" }}>
              CS2 CHAMPIONSHIP
            </div>
            <div style={{ color: "#FFB800", fontSize: 10, fontWeight: 700, fontFamily: "DM Mono, monospace" }}>
              ПРИЗОВОЙ ФОНД: 100 000 ₽
            </div>
          </div>
          <div style={{
            background: "linear-gradient(135deg, #00D4FF, #A855F7)",
            borderRadius: 8, padding: "4px 10px",
            boxShadow: "0 0 14px rgba(0,212,255,0.4)",
          }}>
            <span style={{ color: "#fff", fontSize: 9, fontWeight: 800, fontFamily: "Orbitron, sans-serif" }}>5v5</span>
          </div>
        </div>
      </div>

      {/* Post text */}
      <div style={{ padding: "10px 14px 0" }}>
        <p style={{ color: "rgba(255,255,255,0.85)", fontSize: 12, lineHeight: 1.5, margin: 0 }}>
          <span style={{ color: "#A855F7", fontWeight: 700 }}>Турнир по CS2!</span>
          {" "}Призовой фонд 100&nbsp;000&nbsp;₽. Регистрация до 10&nbsp;июля.
          Осталось <span style={{ color: "#FF6B00", fontWeight: 700 }}>6 слотов</span>.
        </p>
      </div>

      {/* Tournament bracket */}
      <div style={{ margin: "10px 14px 0" }}>
        <div style={{
          background: "rgba(0,212,255,0.04)",
          border: "1px solid rgba(0,212,255,0.12)",
          borderRadius: 12, padding: "10px 10px",
        }}>
          <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 8 }}>
            <Trophy size={11} color="#00D4FF" />
            <span style={{ color: "rgba(255,255,255,0.5)", fontSize: 9, fontWeight: 700, letterSpacing: "0.08em", textTransform: "uppercase" }}>
              Сетка турнира · Финал
            </span>
          </div>
          <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
            <div style={{ flex: 1 }}>
              <BracketLine team1="NOVA ESPORTS" team2="GHOST SQUAD" winner={1} score1="16" score2="9" />
            </div>
            <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 2 }}>
              <div style={{ width: 1, height: 12, background: "rgba(0,212,255,0.3)" }} />
              <div style={{ width: 10, height: 1, background: "rgba(0,212,255,0.3)" }} />
              <div style={{ width: 1, height: 12, background: "rgba(0,212,255,0.3)" }} />
            </div>
            <div style={{ flex: 1 }}>
              <div style={{
                background: "linear-gradient(135deg, rgba(0,212,255,0.15), rgba(168,85,247,0.15))",
                border: "1px solid rgba(0,212,255,0.35)",
                borderRadius: 5, padding: "5px 7px", textAlign: "center",
              }}>
                <div style={{ color: "#fff", fontSize: 8, fontWeight: 700, fontFamily: "Orbitron, sans-serif" }}>ФИНАЛ</div>
                <div style={{ color: "#00D4FF", fontSize: 11, fontWeight: 800, fontFamily: "DM Mono, monospace", marginTop: 1 }}>15:00</div>
                <div style={{ color: "rgba(255,255,255,0.4)", fontSize: 7.5, marginTop: 1 }}>11 июля</div>
              </div>
            </div>
            <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 2 }}>
              <div style={{ width: 1, height: 12, background: "rgba(168,85,247,0.3)" }} />
              <div style={{ width: 10, height: 1, background: "rgba(168,85,247,0.3)" }} />
              <div style={{ width: 1, height: 12, background: "rgba(168,85,247,0.3)" }} />
            </div>
            <div style={{ flex: 1 }}>
              <BracketLine team1="STORM FORCE" team2="RED WOLVES" winner={1} score1="16" score2="12" />
            </div>
          </div>
        </div>
      </div>

      {/* Participants */}
      <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "8px 14px 0" }}>
        <div style={{ display: "flex" }}>
          {["photo-1580046939256-c377c5b099f1", "photo-1634910440823-193b061d28a5", "photo-1610041321420-a596dd14ebc9"].map((id, i) => (
            <div key={id} style={{
              width: 22, height: 22, borderRadius: "50%",
              border: "2px solid #060912",
              overflow: "hidden",
              marginLeft: i > 0 ? -8 : 0,
            }}>
              <img src={`https://images.unsplash.com/${id}?w=44&h=44&fit=crop&auto=format`} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
            </div>
          ))}
        </div>
        <span style={{ color: "rgba(255,255,255,0.45)", fontSize: 10 }}>+214 участника</span>
        <div style={{ display: "flex", alignItems: "center", gap: 3, marginLeft: "auto" }}>
          <Flame size={12} color="#FF6B00" />
          <span style={{ color: "#FF6B00", fontSize: 10, fontWeight: 700 }}>Горячо!</span>
        </div>
      </div>

      {/* Actions */}
      <div style={{ display: "flex", alignItems: "center", gap: 6, padding: "10px 14px" }}>
        <button
          onClick={toggleLike}
          style={{
            display: "flex", alignItems: "center", gap: 5,
            background: liked ? "rgba(255,45,85,0.12)" : "rgba(255,255,255,0.04)",
            border: `1px solid ${liked ? "rgba(255,45,85,0.35)" : "rgba(255,255,255,0.08)"}`,
            borderRadius: 10, padding: "7px 12px",
            cursor: "pointer", color: liked ? "#FF2D55" : "rgba(255,255,255,0.5)",
            fontSize: 11, fontWeight: 600,
          }}
        >
          <Heart size={13} fill={liked ? "#FF2D55" : "none"} color={liked ? "#FF2D55" : "rgba(255,255,255,0.5)"} />
          {likes}
        </button>
        <button style={{
          display: "flex", alignItems: "center", gap: 5,
          background: "rgba(255,255,255,0.04)",
          border: "1px solid rgba(255,255,255,0.08)",
          borderRadius: 10, padding: "7px 12px",
          cursor: "pointer", color: "rgba(255,255,255,0.5)",
          fontSize: 11, fontWeight: 600,
        }}>
          <MessageCircle size={13} color="rgba(255,255,255,0.5)" />
          93
        </button>
        <button style={{
          width: 34, height: 34,
          background: "rgba(255,255,255,0.04)",
          border: "1px solid rgba(255,255,255,0.08)",
          borderRadius: 10,
          display: "flex", alignItems: "center", justifyContent: "center",
          cursor: "pointer",
        }}>
          <Share2 size={13} color="rgba(255,255,255,0.5)" />
        </button>
        <button
          onClick={() => setJoined(!joined)}
          style={{
            flex: 1,
            background: joined ? "rgba(0,212,255,0.1)" : "linear-gradient(90deg,#00D4FF,#A855F7)",
            border: joined ? "1px solid rgba(0,212,255,0.4)" : "none",
            borderRadius: 10, padding: "7px 0",
            color: "#fff", fontSize: 11, fontWeight: 800,
            fontFamily: "Rajdhani, sans-serif", letterSpacing: "0.08em",
            cursor: "pointer",
            boxShadow: joined ? "none" : "0 0 16px rgba(0,212,255,0.35)",
          }}
        >
          {joined ? "ЗАПИСАН ✓" : "УЧАСТВОВАТЬ"}
        </button>
      </div>
    </div>
  );
}

function SecondPost() {
  const [liked, setLiked] = useState(false);
  return (
    <div style={{
      margin: "0 12px 20px",
      background: "rgba(255,255,255,0.03)",
      backdropFilter: "blur(20px)",
      border: "1px solid rgba(255,255,255,0.06)",
      borderRadius: 18, overflow: "hidden",
    }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "12px 14px 10px" }}>
        <div style={{
          width: 36, height: 36, borderRadius: "50%",
          border: "2px solid #FF6B00",
          overflow: "hidden",
          boxShadow: "0 0 10px rgba(255,107,0,0.5)",
        }}>
          <img
            src="https://images.unsplash.com/photo-1610041321420-a596dd14ebc9?w=72&h=72&fit=crop&auto=format"
            alt=""
            style={{ width: "100%", height: "100%", objectFit: "cover" }}
          />
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
            <span style={{ color: "#fff", fontSize: 11, fontWeight: 700, fontFamily: "Rajdhani, sans-serif" }}>n1ko_pro</span>
            <BadgeCheck size={11} color="#FF6B00" />
          </div>
          <span style={{ color: "rgba(255,255,255,0.3)", fontSize: 9 }}>5 часов назад</span>
        </div>
        <div style={{ background: "rgba(0,212,255,0.1)", border: "1px solid rgba(0,212,255,0.25)", borderRadius: 6, padding: "2px 7px" }}>
          <span style={{ color: "#00D4FF", fontSize: 8, fontWeight: 700, fontFamily: "Orbitron, sans-serif" }}>TOP-1</span>
        </div>
      </div>
      <div style={{ padding: "0 14px 10px" }}>
        <p style={{ color: "rgba(255,255,255,0.8)", fontSize: 12, lineHeight: 1.5, margin: "0 0 8px" }}>
          Только что взял <span style={{ color: "#FF6B00", fontWeight: 700 }}>1 место</span> на турнире по Valorant в CYBERIA PRO 🏆 Спасибо всем за поддержку!
        </p>
        <div style={{ display: "flex", gap: 6 }}>
          <button
            onClick={() => setLiked(!liked)}
            style={{
              display: "flex", alignItems: "center", gap: 5,
              background: liked ? "rgba(255,45,85,0.1)" : "rgba(255,255,255,0.04)",
              border: `1px solid ${liked ? "rgba(255,45,85,0.3)" : "rgba(255,255,255,0.07)"}`,
              borderRadius: 8, padding: "6px 10px",
              cursor: "pointer", color: liked ? "#FF2D55" : "rgba(255,255,255,0.45)",
              fontSize: 10, fontWeight: 600,
            }}
          >
            <Heart size={11} fill={liked ? "#FF2D55" : "none"} color={liked ? "#FF2D55" : "rgba(255,255,255,0.45)"} />
            {liked ? 1205 : 1204}
          </button>
          <button style={{
            display: "flex", alignItems: "center", gap: 5,
            background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.07)",
            borderRadius: 8, padding: "6px 10px", cursor: "pointer",
            color: "rgba(255,255,255,0.45)", fontSize: 10, fontWeight: 600,
          }}>
            <MessageCircle size={11} color="rgba(255,255,255,0.45)" />
            142
          </button>
        </div>
      </div>
    </div>
  );
}

const NAV = [
  { icon: MapPin, label: "Карта" },
  { icon: Trophy, label: "Турниры" },
  { icon: LayoutList, label: "Лента" },
  { icon: Calendar, label: "Бронь" },
  { icon: User, label: "Профиль" },
];

export function FeedScreen() {
  const [activeNav, setActiveNav] = useState("Лента");

  return (
    <div style={{ height: "100%", display: "flex", flexDirection: "column", background: "#060912", fontFamily: "Inter, sans-serif", overflow: "hidden" }}>
      {/* Glassmorphic top bar */}
      <div style={{
        flexShrink: 0,
        background: "rgba(6,9,18,0.85)",
        backdropFilter: "blur(24px)",
        WebkitBackdropFilter: "blur(24px)",
        borderBottom: "1px solid rgba(255,255,255,0.06)",
        paddingTop: 50,
        boxShadow: "0 4px 30px rgba(0,0,0,0.4)",
      }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "0 16px 10px" }}>
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
              <span style={{ color: "#00D4FF", fontSize: 16, fontWeight: 900, fontFamily: "Orbitron, sans-serif", letterSpacing: "0.08em" }}>GAMER</span>
              <span style={{ color: "#A855F7", fontSize: 16, fontWeight: 900, fontFamily: "Orbitron, sans-serif" }}>MAP</span>
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 4, marginTop: 1 }}>
              <div style={{ width: 5, height: 5, borderRadius: "50%", background: "#00FF88", boxShadow: "0 0 6px #00FF88" }} />
              <span style={{ color: "rgba(255,255,255,0.35)", fontSize: 9 }}>17 активных турниров</span>
            </div>
          </div>
          <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
            <button style={{
              width: 32, height: 32, borderRadius: 9,
              background: "rgba(255,255,255,0.05)",
              border: "1px solid rgba(255,255,255,0.08)",
              display: "flex", alignItems: "center", justifyContent: "center",
              cursor: "pointer",
            }}>
              <Search size={14} color="rgba(255,255,255,0.6)" />
            </button>
            <button style={{
              width: 32, height: 32, borderRadius: 9,
              background: "rgba(168,85,247,0.12)",
              border: "1px solid rgba(168,85,247,0.3)",
              display: "flex", alignItems: "center", justifyContent: "center",
              cursor: "pointer", position: "relative",
              boxShadow: "0 0 10px rgba(168,85,247,0.2)",
            }}>
              <Bell size={14} color="#A855F7" />
              <div style={{
                position: "absolute", top: 5, right: 5,
                width: 6, height: 6, borderRadius: "50%",
                background: "#FF2D55", border: "1px solid #060912",
                boxShadow: "0 0 6px #FF2D55",
              }} />
            </button>
          </div>
        </div>
      </div>

      {/* Feed */}
      <div style={{ flex: 1, overflowY: "auto", scrollbarWidth: "none" }}>
        {/* Stories */}
        <div style={{ padding: "12px 12px 10px", display: "flex", gap: 10, overflowX: "auto", scrollbarWidth: "none" }}>
          {STORIES.map(({ name, url, color, isMe }) => (
            <div key={name} style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 5, flexShrink: 0 }}>
              <div style={{ position: "relative" }}>
                <div style={{
                  width: isMe ? 52 : 50,
                  height: isMe ? 52 : 50,
                  borderRadius: "50%",
                  padding: 2,
                  background: isMe ? "rgba(255,255,255,0.08)" : `linear-gradient(135deg, ${color}, ${color}80)`,
                  boxShadow: isMe ? "none" : `0 0 10px ${color}60`,
                }}>
                  <div style={{ width: "100%", height: "100%", borderRadius: "50%", overflow: "hidden", border: "2px solid #060912" }}>
                    <img
                      src={`https://images.unsplash.com/${url}?w=100&h=100&fit=crop&auto=format`}
                      alt={name}
                      style={{ width: "100%", height: "100%", objectFit: "cover" }}
                    />
                  </div>
                </div>
                {isMe && (
                  <div style={{
                    position: "absolute", bottom: 0, right: 0,
                    width: 16, height: 16, borderRadius: "50%",
                    background: "linear-gradient(135deg, #00D4FF, #A855F7)",
                    display: "flex", alignItems: "center", justifyContent: "center",
                    border: "2px solid #060912",
                    boxShadow: "0 0 8px rgba(0,212,255,0.5)",
                    fontSize: 9, color: "#fff", fontWeight: 900,
                  }}>+</div>
                )}
              </div>
              <span style={{ color: "rgba(255,255,255,0.55)", fontSize: 9, fontFamily: "Inter, sans-serif", maxWidth: 52, textAlign: "center", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                {name}
              </span>
            </div>
          ))}
        </div>

        {/* Tournament alert banner */}
        <div style={{ margin: "0 12px 10px" }}>
          <div style={{
            background: "linear-gradient(90deg, rgba(255,107,0,0.12), rgba(168,85,247,0.12))",
            border: "1px solid rgba(255,107,0,0.25)",
            borderRadius: 12, padding: "8px 12px",
            display: "flex", alignItems: "center", gap: 8,
            boxShadow: "0 0 16px rgba(255,107,0,0.08)",
          }}>
            <Zap size={14} color="#FF6B00" style={{ filter: "drop-shadow(0 0 4px rgba(255,107,0,0.8))" }} />
            <div style={{ flex: 1 }}>
              <span style={{ color: "#FF6B00", fontSize: 10, fontWeight: 700, fontFamily: "Rajdhani, sans-serif", letterSpacing: "0.05em" }}>
                3 турнира начинаются через 2 часа
              </span>
            </div>
            <ChevronRight size={13} color="rgba(255,107,0,0.7)" />
          </div>
        </div>

        {/* Posts */}
        <PostCard />
        <SecondPost />
      </div>

      {/* Bottom nav */}
      <div style={{
        flexShrink: 0,
        background: "rgba(6,9,18,0.97)",
        backdropFilter: "blur(20px)",
        borderTop: "1px solid rgba(255,255,255,0.05)",
        display: "flex",
        padding: "7px 0 18px",
      }}>
        {NAV.map(({ icon: Icon, label }) => {
          const active = activeNav === label;
          return (
            <button
              key={label}
              onClick={() => setActiveNav(label)}
              style={{
                flex: 1, display: "flex", flexDirection: "column",
                alignItems: "center", gap: 3,
                background: "none", border: "none", cursor: "pointer", padding: "3px 0",
              }}
            >
              <Icon
                size={19}
                color={active ? "#A855F7" : "rgba(255,255,255,0.3)"}
                style={active ? { filter: "drop-shadow(0 0 5px rgba(168,85,247,0.9))" } : {}}
              />
              <span style={{
                fontSize: 8.5,
                color: active ? "#A855F7" : "rgba(255,255,255,0.3)",
                fontFamily: "Inter, sans-serif",
                fontWeight: active ? 600 : 400,
              }}>{label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
