import { MapScreen } from "./components/MapScreen";
import { ClubScreen } from "./components/ClubScreen";
import { FeedScreen } from "./components/FeedScreen";

function PhoneFrame({ children, label, accent }: {
  children: React.ReactNode;
  label: string;
  accent: string;
}) {
  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 20, flexShrink: 0 }}>
      {/* Label tag */}
      <div style={{
        background: "rgba(255,255,255,0.04)",
        border: "1px solid rgba(255,255,255,0.08)",
        borderRadius: 20, padding: "5px 14px",
        display: "flex", alignItems: "center", gap: 8,
      }}>
        <div style={{ width: 6, height: 6, borderRadius: "50%", background: accent, boxShadow: `0 0 8px ${accent}` }} />
        <span style={{ color: "rgba(255,255,255,0.4)", fontSize: 10, fontFamily: "DM Mono, monospace", letterSpacing: "0.1em", textTransform: "uppercase" }}>
          {label}
        </span>
      </div>

      {/* Phone shell */}
      <div style={{
        position: "relative",
        width: 330,
        height: 716,
        flexShrink: 0,
      }}>
        {/* Outer rim glow */}
        <div style={{
          position: "absolute",
          inset: -1,
          borderRadius: 48,
          background: `linear-gradient(135deg, ${accent}30, transparent 60%, rgba(168,85,247,0.2))`,
          filter: "blur(1px)",
        }} />

        {/* Phone body */}
        <div style={{
          position: "absolute",
          inset: 0,
          borderRadius: 46,
          background: "linear-gradient(160deg, #151820 0%, #0c0e16 60%, #080b14 100%)",
          border: "1.5px solid rgba(255,255,255,0.1)",
          overflow: "hidden",
          boxShadow: `
            0 0 0 5px #0e1018,
            0 40px 120px rgba(0,0,0,0.85),
            0 8px 40px rgba(0,0,0,0.6),
            inset 0 1px 0 rgba(255,255,255,0.06),
            inset 0 -1px 0 rgba(0,0,0,0.4),
            0 0 60px ${accent}12
          `,
        }}>
          {/* Dynamic Island */}
          <div style={{
            position: "absolute", top: 12, left: "50%",
            transform: "translateX(-50%)",
            width: 120, height: 34,
            background: "#000",
            borderRadius: 20,
            zIndex: 100,
            boxShadow: "0 0 0 1px rgba(255,255,255,0.04)",
          }}>
            {/* Camera + FaceID dots */}
            <div style={{
              position: "absolute", top: "50%", right: 14,
              transform: "translateY(-50%)",
              width: 10, height: 10, borderRadius: "50%",
              background: "#1a1a2e",
              border: "1px solid rgba(255,255,255,0.06)",
            }}>
              <div style={{
                position: "absolute", top: "50%", left: "50%",
                transform: "translate(-50%,-50%)",
                width: 4, height: 4, borderRadius: "50%",
                background: "#2a2a4e",
              }} />
            </div>
          </div>

          {/* Screen content */}
          <div style={{ position: "absolute", inset: 0 }}>
            {children}
          </div>

          {/* Home indicator */}
          <div style={{
            position: "absolute", bottom: 6, left: "50%",
            transform: "translateX(-50%)",
            width: 100, height: 4,
            background: "rgba(255,255,255,0.12)",
            borderRadius: 3,
            zIndex: 200,
          }} />
        </div>

        {/* Side buttons */}
        <div style={{
          position: "absolute", right: -2, top: 120,
          width: 3, height: 40,
          background: "rgba(255,255,255,0.08)",
          borderRadius: "0 2px 2px 0",
        }} />
        <div style={{
          position: "absolute", left: -2, top: 100,
          width: 3, height: 28,
          background: "rgba(255,255,255,0.08)",
          borderRadius: "2px 0 0 2px",
        }} />
        <div style={{
          position: "absolute", left: -2, top: 140,
          width: 3, height: 50,
          background: "rgba(255,255,255,0.08)",
          borderRadius: "2px 0 0 2px",
        }} />
        <div style={{
          position: "absolute", left: -2, top: 200,
          width: 3, height: 50,
          background: "rgba(255,255,255,0.08)",
          borderRadius: "2px 0 0 2px",
        }} />
      </div>

      {/* Screen number */}
      <div style={{ color: "rgba(255,255,255,0.15)", fontSize: 9, fontFamily: "DM Mono, monospace", letterSpacing: "0.2em" }}>
        {label.split("·")[0].trim()}
      </div>
    </div>
  );
}

export default function App() {
  return (
    <div style={{
      minHeight: "100vh",
      background: "#080a10",
      overflowX: "auto",
      overflowY: "auto",
      fontFamily: "Inter, sans-serif",
    }}>
      {/* Keyframe animations */}
      <style>{`
        @keyframes gmap-pulse {
          0% { transform: translateX(-50%) scale(1); opacity: 0.7; }
          100% { transform: translateX(-50%) scale(2.8); opacity: 0; }
        }
        @keyframes neon-breathe {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.6; }
        }
        * { scrollbar-width: none; }
        *::-webkit-scrollbar { display: none; }
      `}</style>

      {/* Background texture */}
      <div style={{
        position: "fixed", inset: 0, pointerEvents: "none", zIndex: 0,
        backgroundImage: `
          radial-gradient(ellipse at 15% 30%, rgba(0,212,255,0.06) 0%, transparent 45%),
          radial-gradient(ellipse at 85% 70%, rgba(168,85,247,0.07) 0%, transparent 45%),
          radial-gradient(ellipse at 50% 50%, rgba(255,107,0,0.03) 0%, transparent 60%),
          linear-gradient(rgba(255,255,255,0.012) 1px, transparent 1px),
          linear-gradient(90deg, rgba(255,255,255,0.012) 1px, transparent 1px)
        `,
        backgroundSize: "100% 100%, 100% 100%, 100% 100%, 26px 26px, 26px 26px",
      }} />

      {/* Figma-style top bar */}
      <div style={{
        position: "sticky", top: 0, zIndex: 300,
        height: 48,
        background: "rgba(18,20,30,0.96)",
        backdropFilter: "blur(20px)",
        WebkitBackdropFilter: "blur(20px)",
        borderBottom: "1px solid rgba(255,255,255,0.05)",
        display: "flex", alignItems: "center", padding: "0 18px", gap: 20,
        boxShadow: "0 1px 0 rgba(255,255,255,0.03), 0 4px 20px rgba(0,0,0,0.5)",
      }}>
        {/* Traffic lights */}
        <div style={{ display: "flex", gap: 7 }}>
          {[["#FF5F57", "#FF3B30"], ["#FFBD2E", "#FF9500"], ["#28CA41", "#34C759"]].map(([fill, glow]) => (
            <div key={fill} style={{
              width: 12, height: 12, borderRadius: "50%",
              background: fill,
              boxShadow: `0 0 6px ${glow}80`,
            }} />
          ))}
        </div>

        {/* Left tools */}
        <div style={{ display: "flex", gap: 6 }}>
          {["▸", "⊞", "⬡", "T", "✎"].map((t, i) => (
            <div key={i} style={{
              width: 28, height: 28, borderRadius: 6,
              background: i === 0 ? "rgba(0,212,255,0.12)" : "rgba(255,255,255,0.04)",
              border: `1px solid ${i === 0 ? "rgba(0,212,255,0.25)" : "rgba(255,255,255,0.06)"}`,
              display: "flex", alignItems: "center", justifyContent: "center",
              color: i === 0 ? "#00D4FF" : "rgba(255,255,255,0.35)",
              fontSize: 11, cursor: "pointer",
            }}>{t}</div>
          ))}
        </div>

        {/* Center title */}
        <div style={{ flex: 1, display: "flex", justifyContent: "center" }}>
          <div style={{
            background: "rgba(255,255,255,0.04)",
            border: "1px solid rgba(255,255,255,0.07)",
            borderRadius: 8, padding: "5px 20px",
            display: "flex", alignItems: "center", gap: 8,
          }}>
            <span style={{ color: "#00D4FF", fontSize: 11, fontFamily: "Orbitron, sans-serif", fontWeight: 700 }}>GAMER</span>
            <span style={{ color: "#A855F7", fontSize: 11, fontFamily: "Orbitron, sans-serif", fontWeight: 700 }}>MAP</span>
            <span style={{ color: "rgba(255,255,255,0.2)", fontSize: 11 }}>·</span>
            <span style={{ color: "rgba(255,255,255,0.35)", fontSize: 11 }}>UI Kit v2.0</span>
          </div>
        </div>

        {/* Right actions */}
        <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
          {["100%", "Дизайн", "Прото", "Инспект"].map((t, i) => (
            <div key={t} style={{
              padding: "4px 10px", borderRadius: 6,
              background: i === 0 ? "rgba(255,255,255,0.05)" : "transparent",
              border: i === 0 ? "1px solid rgba(255,255,255,0.08)" : "none",
              color: i === 1 ? "rgba(255,255,255,0.8)" : "rgba(255,255,255,0.35)",
              fontSize: 11, cursor: "pointer",
              borderBottom: i === 1 ? "1px solid #00D4FF" : "none",
            }}>{t}</div>
          ))}
          <div style={{
            padding: "5px 16px", borderRadius: 8,
            background: "linear-gradient(90deg, #00D4FF, #A855F7)",
            color: "#fff", fontSize: 11, fontWeight: 700,
            cursor: "pointer",
            boxShadow: "0 0 16px rgba(0,212,255,0.3)",
          }}>Поделиться</div>
        </div>
      </div>

      {/* Left sidebar panel (Figma layers) */}
      <div style={{
        position: "fixed", left: 0, top: 48, bottom: 0,
        width: 40, zIndex: 200,
        background: "rgba(14,16,24,0.95)",
        backdropFilter: "blur(10px)",
        borderRight: "1px solid rgba(255,255,255,0.04)",
        display: "flex", flexDirection: "column",
        alignItems: "center", gap: 16, paddingTop: 16,
      }}>
        {["⊟", "◈", "⬡", "☷"].map((icon, i) => (
          <div key={i} style={{
            width: 28, height: 28, borderRadius: 6,
            display: "flex", alignItems: "center", justifyContent: "center",
            color: i === 2 ? "#00D4FF" : "rgba(255,255,255,0.25)",
            fontSize: 13, cursor: "pointer",
          }}>{icon}</div>
        ))}
      </div>

      {/* Right sidebar (Figma properties) */}
      <div style={{
        position: "fixed", right: 0, top: 48, bottom: 0,
        width: 40, zIndex: 200,
        background: "rgba(14,16,24,0.95)",
        backdropFilter: "blur(10px)",
        borderLeft: "1px solid rgba(255,255,255,0.04)",
        display: "flex", flexDirection: "column",
        alignItems: "center", gap: 16, paddingTop: 16,
      }}>
        {["⚙", "◻", "✦", "∷"].map((icon, i) => (
          <div key={i} style={{
            width: 28, height: 28, borderRadius: 6,
            display: "flex", alignItems: "center", justifyContent: "center",
            color: i === 0 ? "#A855F7" : "rgba(255,255,255,0.25)",
            fontSize: 13, cursor: "pointer",
          }}>{icon}</div>
        ))}
      </div>

      {/* Canvas */}
      <div style={{
        position: "relative", zIndex: 1,
        minWidth: "max-content",
        padding: "60px 80px 80px 60px",
        marginLeft: 40,
        marginRight: 40,
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        gap: 0,
      }}>
        {/* Canvas label */}
        <div style={{
          marginBottom: 40,
          display: "flex", alignItems: "center", gap: 12,
        }}>
          <div style={{ height: 1, width: 80, background: "rgba(255,255,255,0.06)" }} />
          <span style={{ color: "rgba(255,255,255,0.2)", fontSize: 10, fontFamily: "DM Mono, monospace", letterSpacing: "0.15em", textTransform: "uppercase" }}>
            GamerMap · Mobile App · 3 экрана
          </span>
          <div style={{ height: 1, width: 80, background: "rgba(255,255,255,0.06)" }} />
        </div>

        {/* Three phones */}
        <div style={{ display: "flex", gap: 48, alignItems: "flex-start" }}>
          <PhoneFrame label="Экран 1 · Карта" accent="#00D4FF">
            <MapScreen />
          </PhoneFrame>

          <PhoneFrame label="Экран 2 · Профиль клуба" accent="#A855F7">
            <ClubScreen />
          </PhoneFrame>

          <PhoneFrame label="Экран 3 · Лента" accent="#FF6B00">
            <FeedScreen />
          </PhoneFrame>
        </div>

        {/* Bottom annotation */}
        <div style={{
          marginTop: 48,
          display: "flex", gap: 24, alignItems: "center",
        }}>
          {[
            { label: "Glassmorphism", color: "#00D4FF" },
            { label: "Neon Glow FX", color: "#A855F7" },
            { label: "Dark Mode", color: "#FF6B00" },
            { label: "HyperOS Style", color: "#00FF88" },
          ].map(({ label, color }) => (
            <div key={label} style={{ display: "flex", alignItems: "center", gap: 6 }}>
              <div style={{ width: 8, height: 8, borderRadius: 2, background: color, boxShadow: `0 0 8px ${color}` }} />
              <span style={{ color: "rgba(255,255,255,0.25)", fontSize: 10, fontFamily: "DM Mono, monospace" }}>{label}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
