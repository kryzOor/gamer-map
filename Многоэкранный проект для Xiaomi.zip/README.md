
  # Многоэкранный проект для Xiaomi

  This is a code bundle for Многоэкранный проект для Xiaomi. The original project is available at https://www.figma.com/design/SJoWQ0JLeWPYY9FJQiiR8y/%D0%9C%D0%BD%D0%BE%D0%B3%D0%BE%D1%8D%D0%BA%D1%80%D0%B0%D0%BD%D0%BD%D1%8B%D0%B9-%D0%BF%D1%80%D0%BE%D0%B5%D0%BA%D1%82-%D0%B4%D0%BB%D1%8F-Xiaomi.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  